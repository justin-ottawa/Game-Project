package data;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.opengl.Texture;

import UI.UI;
import helpers.StateManager;
import helpers.StateManager.*;

import static helpers.Artist.*;

public class InstructionMenu {	
	private Texture background;
	private UI menuUI;
	
	public InstructionMenu() {
		
		background = QuickLoad("Instructions");
		menuUI = new UI();
		menuUI.addButton("Back", "backButton", WIDTH / 2 - 192, (int) (HEIGHT * 0.11f));
	}
	
	private void updateButtons() {
		if (Mouse.isButtonDown(0)) {
			if(menuUI.isButtonClicked("Back"))
				StateManager.setState(GameState.MAINMENU);
		}
	}
	
	public void update() {
		DrawQuadTex(background, 0, 0, 1024, 2048);
		menuUI.draw();
		updateButtons();
	}
}
