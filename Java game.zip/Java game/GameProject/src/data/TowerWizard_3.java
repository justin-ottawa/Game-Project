package data;

import java.util.concurrent.CopyOnWriteArrayList;

public class TowerWizard_3 extends Tower {

	public TowerWizard_3(TowerType type, Tile startTile, CopyOnWriteArrayList<Slime> slimes) {
		super(type, startTile, slimes);
	}
	
	@Override
	public void shoot(Slime target) {
		super.projectiles.add(new ProjectileFireBall(super.type.type, super.target, super.getX(), super.getY(), 32, 32));
		super.target.reduceHiddenHealth(super.type.type.damage);
	}
}