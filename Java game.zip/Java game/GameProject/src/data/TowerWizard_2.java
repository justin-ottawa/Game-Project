package data;

import java.util.concurrent.CopyOnWriteArrayList;

public class TowerWizard_2 extends Tower {
	
	public TowerWizard_2(TowerType type, Tile startTile, CopyOnWriteArrayList<Slime> slimes) {
		super(type, startTile, slimes);
	}

	@Override
	public void shoot(Slime target) {
		super.projectiles.add(new ProjectileIceBall(super.type.type, super.target, super.getX(), super.getY(), 32, 32));
		super.target.reduceHiddenHealth(super.type.type.damage);
	}
	
}
