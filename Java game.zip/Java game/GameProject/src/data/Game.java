package data;

import static helpers.Artist.*;

import java.util.Random;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.opengl.Texture;

import UI.UI;
import UI.UI.Menu;
import helpers.StateManager;
import helpers.StateManager.GameState;

public class Game {

	private TileGrid grid;
	private Player player;
	private WaveManager waveManager;
	private UI gameUI;
	private Menu towerPickerMenu;
	private Texture menuBackground;
	private Slime[] slimeTypes;

	public Game(TileGrid grid) {
		this.grid = grid;
		this.menuBackground = QuickLoad("menu_background");
		slimeTypes = new Slime[3];
		slimeTypes[0] = new SlimeGreen(0, 1, grid);
		slimeTypes[1] = new SlimeBlue(0, 1, grid);
		slimeTypes[2] = new SlimeRed(0, 1, grid);

		waveManager = new WaveManager(slimeTypes, 2, 1);
		player = new Player(grid, waveManager);
		player.setup();
		setupUI();
	}

	private void setupUI() {
		gameUI = new UI();
		gameUI.createMenu("TowerPicker", 1280, 75, 192, 960, 2, 0);
		towerPickerMenu = gameUI.getMenu("TowerPicker");
		towerPickerMenu.quickAdd("WizardFire", "wizard_3");
		towerPickerMenu.quickAdd("WizardIce", "wizard_2");
		towerPickerMenu.quickAdd("WizardNormal", "wizard_1");
		towerPickerMenu.quickAdd("WizardGrass", "wizard_4");
	}

	private void updateUI() {
		gameUI.draw();
		gameUI.drawString(1320, 700, "Lives: " + Player.Lives);
		gameUI.drawString(1320, 800, "Power: " + Player.Power);
		gameUI.drawString(1310, 130, "100");
		gameUI.drawString(1400, 130, "60");
		gameUI.drawString(1320, 260, "30");
		gameUI.drawString(1400, 260, "45");
		gameUI.drawString(1320, 600, "Wave " + waveManager.getWaveNumber());
		gameUI.drawString(0, 0, StateManager.framesInLastSecond + " FPS");

		if (Mouse.next()) {
			boolean mouseClicked = Mouse.isButtonDown(0);

			if (mouseClicked) {
				if (towerPickerMenu.isButtonClicked("WizardFire"))
					player.pickTower(new TowerWizard_3(TowerType.Wizard3, grid.getTile(0, 0),
							waveManager.getCurrentWave().getSlimeList()));
				if (towerPickerMenu.isButtonClicked("WizardIce"))
					player.pickTower(new TowerWizard_2(TowerType.Wizard2, grid.getTile(0, 0),
							waveManager.getCurrentWave().getSlimeList()));
				if (towerPickerMenu.isButtonClicked("WizardNormal"))
					player.pickTower(new TowerWizard_1(TowerType.Wizard1, grid.getTile(0, 0),
							waveManager.getCurrentWave().getSlimeList()));
				if (towerPickerMenu.isButtonClicked("WizardGrass"))
					player.pickTower(new TowerWizard_4(TowerType.Wizard4, grid.getTile(0, 0),
							waveManager.getCurrentWave().getSlimeList()));

			}
		}
	}

	public void update() {
		DrawQuadTex(menuBackground, 1280, 0, 1920, 960);
		grid.draw();
		waveManager.update();
		player.update();
		updateUI();
		if (Player.Lives == 0)
			StateManager.setState(GameState.ENDSCREEN);
	}
}
