package data;

import org.newdawn.slick.opengl.Texture;

public class ProjectileFireBall extends Projectile{

	public ProjectileFireBall(ProjectileType type, Slime target, float x, float y, int width, int height) {
		super(type, target, x, y, width, height);
	}

}
