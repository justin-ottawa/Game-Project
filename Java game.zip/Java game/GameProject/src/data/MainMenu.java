package data;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.opengl.Texture;

import UI.UI;
import helpers.StateManager;
import helpers.StateManager.*;

import static helpers.Artist.*;

public class MainMenu {
	
	private Texture background, background2;
	private UI menuUI;
	
	public MainMenu() {
		background = QuickLoad("mainmenu");
		background2 = QuickLoad("EndMenu");
		menuUI = new UI();
		menuUI.addButton("Play", "playButton", WIDTH / 2 - 192, (int) (HEIGHT * 0.5f));
		menuUI.addButton("Editor", "editButton", WIDTH / 2 - 192, (int) (HEIGHT * 0.61f));
		menuUI.addButton("Instructions", "tutButton", WIDTH / 2 - 192, (int) (HEIGHT * 0.72f));
		menuUI.addButton("Quit", "quitButton", WIDTH / 2 - 192, (int) (HEIGHT * 0.83f));
	}
	
	private void updateButtons() {
		if (Mouse.isButtonDown(0)) {
			if(menuUI.isButtonClicked("Play"))
				StateManager.setState(GameState.GAME);
			if(menuUI.isButtonClicked("Editor"))
				StateManager.setState(GameState.EDITOR);
			if(menuUI.isButtonClicked("Instructions"))
				StateManager.setState(GameState.TUTORIAL);
			if(menuUI.isButtonClicked("Quit"))
				System.exit(0);
		}
	}
	
	public void update() {
		DrawQuadTex(background2, 0, 0, 1024, 2048);
		DrawQuadTex(background, 81, 0, 1024, 2048);
		menuUI.draw();
		updateButtons();
	}
}
