package data;

import org.newdawn.slick.opengl.Texture;
import static helpers.Artist.*;

public enum TowerType {
	
	Wizard1(QuickLoad("wizard1_topdown"), ProjectileType.MagicBall, 10, 1000, 1, 30),
	Wizard2(QuickLoad("wizard2_topdown"), ProjectileType.IceBall, 30, 1000, 1, 60),
	Wizard3(QuickLoad("wizard3_topdown"), ProjectileType.FireBall, 50, 1000, 2, 100),
	Wizard4(QuickLoad("Wizard4_topdown"), ProjectileType.LeafBall, 1, 1000, .2f, 45);
	
	Texture texture;
	ProjectileType type;
	int damage, range, cost;
	float firingSpeed;
	
	TowerType(Texture texture, ProjectileType type, int damage, int range, float firingSpeed, int cost) {
		this.texture = texture;
		this.type = type;
		this.damage = damage;
		this.range = range;
		this.firingSpeed = firingSpeed;
		this.cost = cost;
	}
	
}
