package data;

public class SlimeRed extends Slime {
	public static boolean reset;

	public SlimeRed(int tileX, int tileY, TileGrid grid) {
		super(tileX, tileY, grid);
		this.setTexture("slime_2");
		this.setSpeed(25);
		this.setHealth(1000);
	}
}