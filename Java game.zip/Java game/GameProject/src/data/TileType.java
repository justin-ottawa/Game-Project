package data;

public enum TileType {
	
	Grass("tile_grass", true), Dirt("tile_dirt", false), Water("tile_water", false), NULL("tile_water", false);
	
	String textureName;
	boolean buildable;
	
	TileType(String textureName, boolean buildable) {
		this.textureName = textureName;
		this.buildable = buildable;
	}

}
