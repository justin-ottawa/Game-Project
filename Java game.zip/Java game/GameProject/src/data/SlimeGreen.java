package data;

public class SlimeGreen extends Slime {
	public static boolean reset;

	public SlimeGreen(int tileX, int tileY, TileGrid grid) {
		super(tileX, tileY, grid);
		this.setTexture("slime_1");
		this.setHealth(100);
	}
}
