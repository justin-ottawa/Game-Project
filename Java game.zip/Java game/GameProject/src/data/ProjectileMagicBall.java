package data;

public class ProjectileMagicBall extends Projectile{

	public ProjectileMagicBall(ProjectileType type, Slime target, float x, float y, int width, int height) {
		super(type, target, x, y, width, height);
	}
	
	@Override
	public void damage() {
		super.getTarget();
		super.damage();
	}

}
