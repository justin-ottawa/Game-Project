package data;

public class SlimeBlue extends Slime {
	public static boolean reset;

	public SlimeBlue(int tileX, int tileY, TileGrid grid) {
		super(tileX, tileY, grid);
		this.setTexture("slime_3");
		this.setSpeed(100);
		this.setHealth(65);
	}

}
