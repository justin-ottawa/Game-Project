package data;

import org.lwjgl.input.*;
import org.newdawn.slick.opengl.Texture;

import UI.UI;
import helpers.StateManager;
import helpers.StateManager.GameState;

import static helpers.Artist.*;

public class EndMenu {
	private TileGrid grid;

	private Texture background;
	private UI menuUI;

	public EndMenu(TileGrid grid) {
		this.grid = grid;

		background = QuickLoad("EndMenu");
		menuUI = new UI();
		menuUI.addButton("Quit", "quitButton", WIDTH / 2 - 192, (int) (HEIGHT * 0.72f));
	}

	private void updateButtons() {
		Game g = new Game(grid);
		if (Mouse.isButtonDown(0)) {
			if (menuUI.isButtonClicked("Quit"))
				System.exit(0);
		}
	}

	public void update() {
		DrawQuadTex(background, 0, 0, 1024, 2048);
		menuUI.draw();
		updateButtons();
	}
}
