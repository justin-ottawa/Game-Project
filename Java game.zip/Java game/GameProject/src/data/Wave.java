package data;

import static helpers.Artist.TILE_SIZE;
import static helpers.Clock.Delta;

import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

public class Wave {

	private float timeSinceLastSpawn, spawnTime;
	private Slime[] slimeTypes;
	private CopyOnWriteArrayList<Slime> slimeList;
	private int enemiesPerWave, enemiesSpawned;
	private boolean waveCompleted;

	public Wave(Slime[] slimeTypes, float spawnTime, int enemiesPerWave) {
		this.slimeTypes = slimeTypes;
		this.spawnTime = spawnTime;
		this.enemiesPerWave = enemiesPerWave;
		this.enemiesSpawned = 0;
		this.timeSinceLastSpawn = 0;
		this.slimeList = new CopyOnWriteArrayList<Slime>();
		this.waveCompleted = false;

		spawn();
	}

	public void update() {
		boolean allEnemiesDead = true;
		if (enemiesSpawned < enemiesPerWave) {
			timeSinceLastSpawn += Delta();
			if (timeSinceLastSpawn > spawnTime) {
				spawn();
				timeSinceLastSpawn = 0;
			}
		}
		for (Slime e : slimeList) {
			if (e.isAlive()) {
				allEnemiesDead = false;
				e.update();
				e.draw();
			} else
				slimeList.remove(e);
		}
		if (allEnemiesDead)
			waveCompleted = true;
	}

	private void spawn() {
		int slimeChosen = 0;
		Random rand = new Random();
		slimeChosen = rand.nextInt(slimeTypes.length);

		slimeList.add(new Slime(slimeTypes[slimeChosen].getTexture(), slimeTypes[slimeChosen].getStartTile(),
				slimeTypes[slimeChosen].getTileGrid(), TILE_SIZE, TILE_SIZE, slimeTypes[slimeChosen].getSpeed(),
				slimeTypes[slimeChosen].getHealth()));
		enemiesSpawned++;
	}

	public boolean isCompleted() {
		return waveCompleted;
	}

	public CopyOnWriteArrayList<Slime> getSlimeList() {
		return slimeList;
	}
}
