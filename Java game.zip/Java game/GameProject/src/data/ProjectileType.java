package data;

import static helpers.Artist.QuickLoad;

import org.newdawn.slick.opengl.Texture;

public enum ProjectileType {
	
	MagicBall(QuickLoad("projectile_1"), 8, 600),
	IceBall(QuickLoad("projectile_2"), 6, 450),
	FireBall(QuickLoad("projectile_3"), 30, 750),
	LeafBall(QuickLoad("projectile_4"), 5, 1000);
	
	Texture texture;
	int damage;
	float speed;
	
	ProjectileType(Texture texture, int damage,  float speed) {
		this.texture = texture;
		this.damage = damage;
		this.speed = speed;
	}
	
}
