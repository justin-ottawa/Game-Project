package data;

public class WaveManager {

	private float timeBetweenEnemies;
	int waveNumber;
	private int enemiesPerWave;
	private Slime[] slimeTypes;
	private Wave currentWave;

	public WaveManager(Slime[] slimeTypes, float timeBetweenEnemies, int enemiesPerWave) {
		this.slimeTypes = slimeTypes;
		this.timeBetweenEnemies = timeBetweenEnemies;
		this.enemiesPerWave = enemiesPerWave;
		this.waveNumber = 0;

		this.currentWave = null;

		newWave();
	}

	public void update() {
		if (!currentWave.isCompleted())
			currentWave.update();
		else
			newWave();

	}

	public void newWave() {
		currentWave = new Wave(slimeTypes, timeBetweenEnemies, enemiesPerWave);
		++enemiesPerWave;
		waveNumber++;
		System.out.println("Beginning wave " + waveNumber);

	}

	public Wave getCurrentWave() {
		return currentWave;
	}

	public int getWaveNumber() {
		return waveNumber;
	}

}
